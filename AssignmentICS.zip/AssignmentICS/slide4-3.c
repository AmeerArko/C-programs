#include <stdio.h>
int main(){
      printf("    Hurrah!   UIU Mars Rover Team\n\tachieved 5th place at the\n\t\"URC\" competition.\n");

}