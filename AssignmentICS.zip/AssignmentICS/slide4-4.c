#include <stdio.h>
int main(){
   printf ("D:\\UIU\\Spring24");
}