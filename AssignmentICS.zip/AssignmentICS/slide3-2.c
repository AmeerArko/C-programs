#include <stdio.h>
int main(){
    int length,width,Area;;
    scanf ("%d %d",&length,&width);
   Area=length*width;
    printf ("%d",Area);

}