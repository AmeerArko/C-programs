#include <stdio.h>
int main(){
    float num1,num2,sum;
    scanf ("%f %f",&num1,&num2);
    sum=num1+num2;
    printf ("%.1f",sum);

}