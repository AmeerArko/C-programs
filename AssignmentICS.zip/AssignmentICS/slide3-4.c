#include <stdio.h>
int main(){
    int num1,num2,num3,Avg;
    scanf ("%d %d %d",&num1,&num2,&num3);
    Avg=(num1+num2+num3)/3;
    printf ("%d",Avg);

}