#include <stdio.h>
int main(){
    int height,base,Area;;
    scanf ("%d %d",&height,&base);
   Area=.5*height*base;
    printf ("%d",Area);

}