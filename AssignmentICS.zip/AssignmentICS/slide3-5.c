#include <stdio.h>
int main(){
    int num,rem;
    scanf ("%d",&num);
 rem=num%2;
   if (rem==0){
    printf ("Even");
   }
   else {

   printf("odd");
   }
}