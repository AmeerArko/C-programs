#include <stdio.h>
int main(){
    int temp;
    printf ("Enter the tempreture :");
    scanf ("%d",&temp);
    if (temp<0){
        printf ("Freezing!");
    }
    else if (temp<=14){
        printf ("cold!");
    }
     else if (temp<=25){
        printf ("warm!");
    }
     else if (temp<=35){
        printf ("hot!");
    }
     else {
        printf ("Very Hot!");
     }
}