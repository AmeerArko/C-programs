#include <stdio.h>
int main(){
    int amount;
    printf ("Total water consumption in cubic meters:");
    scanf("%d",&amount);

    if (amount<=30){
        printf ("Flat fee is 500!");

    }
    else if (amount<=50){
        printf ("Flat fee is 1000!");
    }
    else if (amount<=100){
        printf ("Flat fee is 2000!");
    }
    
    else {
        printf ("Flat fee is 3000!");
    }
}