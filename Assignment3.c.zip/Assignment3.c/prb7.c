#include <stdio.h>
int main(){
    int aqi;
    printf ("Enter AQI(Air Quality Index):");
    scanf("%d",&aqi);

    if (aqi<=50){
        printf ("Good!");

    }
    else if (aqi<=100){
        printf ("Moderate!");
    }
    else if (aqi<=150){
        printf ("Unhealthy for sensitive groups");
    }
    else if (aqi<=200){
        printf ("Unhealthy!");
    }
     else if (aqi<=300){
        printf ("Very Unhealthy!");
    }
    else {
        printf ("Hazardous!");
    }
}