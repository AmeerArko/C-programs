#include <stdio.h>
int main(){
    int age;
    printf ("Enter age:");
    scanf("%d",&age);

    if (age<5){
        printf ("Free");

    }
    else if (age<=12){
        printf ("250");
    }
    else if (age<=17){
        printf ("350");
    }
    else if (age<=59){
        printf ("450");
    }
    else {
        printf ("Free");
    }
}