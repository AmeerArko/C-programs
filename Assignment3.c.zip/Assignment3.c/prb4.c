#include <stdio.h>
int main(){
   float amount,discount;
    printf ("Enter Total Purchase Amount:");
    scanf("%f",&amount);

    if (amount<50){
        printf ("No discount!\n");
        printf ("Final Amount %.2f",amount);

    }
    else if (amount<=100){
        printf ("5%% discount!\n");
        discount=.05;
        amount = amount-amount*discount;
         printf ("Final Amount %.2f",amount);
    }
    else if (amount<=200){
        printf ("10%% discount!\n");
         discount=.1;
        amount = amount-amount*discount;
         printf ("Final Amount %.2f",amount);
    }
    else if (amount<=500){
        printf ("15%% discount!\n");
         discount=.15;
        amount = amount-amount*discount;
         printf ("Final Amount %.2f",amount);
    }
    else {
        printf ("20%% discount!\n");
         discount=.2;
        amount = amount-amount*discount;
         printf ("Final Amount %.2f",amount);
    }
}