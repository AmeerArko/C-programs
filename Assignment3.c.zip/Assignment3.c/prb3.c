#include <stdio.h>
int main(){
    int speed;
    printf ("Enter Speed:");
    scanf("%d",&speed);

    if (speed==0){
        printf ("Stopped!");
    }
    else if (speed<=40){
        printf ("Slow!");
    }
    else if (speed<=80){
        printf ("Normal!");
    }
    else if (speed<=120){
        printf ("Very Slow!");
    }
    else {
        printf ("Fast!");
    }
}